//
// Created by MightyPork on 2018/02/03.
//

#include "platform.h"
#include "unit_base.h"
#include "unit_tpl.h"

#define TPL_INTERNAL
#include "_tpl_internal.h"

